var click = document.getElementById("number")
var textSave = document.getElementById("2save")
var count = 0;
var yep = 1;
var hem = 0;


function plus()  {
 count = count + yep; 
  click.textContent = count;
}
function minus()  {
  count = count - 1
  click.textContent = count;
}
function reset() {
  count = hem
  click.textContent = count;
} 
function save() {
  textSave.textContent+= count + "  _  "
}
function resetSave() {
  textSave.textContent = "SAVED CLICKS HERE:<";
}